@extends('layouts.logout')

@section('content')



<div class="logout-from">

  <div class="added-inner">



    <div class="login-title bold">登録ありがとうございます</div>

    <div class="link blue">
      <a href="/login">
        ログイン画面へ
      </a>
    </div>



  </div>

</div>

@endsection

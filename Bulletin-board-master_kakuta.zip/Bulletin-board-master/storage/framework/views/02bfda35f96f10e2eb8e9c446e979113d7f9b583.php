<?php $__env->startSection('content'); ?>

<div class="main">

    <div class="container">
        <div class="inner">
            <div class="category-from">


                <div class="bold">
                    カテゴリー追加画面<br><br>
                </div>

                <?php echo Form::open(); ?>

                <div class="div">
                    <?php echo e(Form::label('新規メインカテゴリー')); ?>

                </div>
                <div class="div">
                    <?php echo e(Form::text('main_category',null,['class' => 'input'])); ?>

                </div>
                    <?php echo Form::button('<div class="link red">登録</div>', ['class' => "btn", 'type' => 'submit' ]); ?>

                <?php echo Form::close(); ?>



                <?php echo Form::open(); ?>

                    <div class="div">
                    <?php echo e(Form::label('メインカテゴリー')); ?>

                    </div>
                    <select name="main_category_id">
                        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->main_category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                    <div class="div">
                    <?php echo e(Form::label('新規サブカテゴリー')); ?>

                    </div>

                    <div class="div">
                    <?php echo e(Form::text('sub_category',null,['class' => 'input'])); ?>

                    </div>

                    <?php echo Form::button('<div class="link red">登録</div>', ['class' => "btn", 'type' => 'submit' ]); ?>

                <?php echo Form::close(); ?>

                <?php if(isset( $errors )): ?>
                    <div class="error-message bold">
                        <div class="error-inner">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>※<?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="main-menu category-list">
        <div class="link blue logout"><a href="/logout">ログアウト</a></div><br>
        <div class="bold">
        カテゴリー一覧
        </div><br>
        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="flex main-flex">
            <div class="div"><?php echo e($category->main_category); ?></div>
            <?php if($category->postSubCategories->isEmpty()): ?>
            <div class="link red">
                <a href="/main/delete/<?php echo e($category->id); ?>" onclick="return confirm('このカテゴリを削除します。よろしいでしょうか？')">
                        削除
                </a>
            </div><br>
            <?php endif; ?>
        </div>



            <?php $__currentLoopData = $category->postSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <div class="flex sub-flex">
                <div class="sub-margin"><?php echo e($sub->sub_category); ?></div>
                <div class="link red">
                    <a href="/sub/delete/<?php echo e($sub->id); ?>" onclick="return confirm('このサブカテゴリを削除します。よろしいでしょうか？')">
                        削除
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shu\Documents\Bulletin-board_Kakuta\Bulletin-board-master\resources\views/category.blade.php ENDPATH**/ ?>
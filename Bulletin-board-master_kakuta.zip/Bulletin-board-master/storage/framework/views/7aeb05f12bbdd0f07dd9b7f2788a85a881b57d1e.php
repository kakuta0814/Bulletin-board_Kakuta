<?php $__env->startSection('content'); ?>
    <div class="post-form">

        <div class="flex">
            <div class="bold">コメント編集画面</div>
            <div class="link blue"><a href="/logout">ログアウト</a></div>
        </div>



      <?php echo Form::open(); ?>


        <?php echo e(Form::label('コメント')); ?>

        <div class="div">
            <?php echo e(Form::textarea('comment',$comment_data->comment,['class' => 'input', 'rows' => '5'])); ?>

        </div>

        <?php echo Form::button('<div class="link red">更新</div>', ['class' => "btn", 'type' => 'submit' ]); ?>



        <div class="link red">
            <a href="<?php echo e(route('comment_delete',['comment_id'=>$comment_data->id])); ?>" onclick="return confirm('この投稿を削除します。よろしいでしょうか？')">
                削除
            </a>
        </div>

        <?php echo Form::close(); ?>


        <?php if(isset( $errors )): ?>
            <div class="error-message bold">
                <div class="error-inner">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>※<?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shu\Documents\Bulletin-board_Kakuta\Bulletin-board-master\resources\views/comment_update.blade.php ENDPATH**/ ?>
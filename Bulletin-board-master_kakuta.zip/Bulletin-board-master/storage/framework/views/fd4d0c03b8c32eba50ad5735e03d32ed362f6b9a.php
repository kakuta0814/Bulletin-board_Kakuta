<?php $__env->startSection('content'); ?>
  <div class="logout-from">

    <div class="logout-inner">
      <?php echo Form::open(); ?>


        <div class="login-title bold">ログイン</div>




        <div class="div">
          <?php echo e(Form::label('メールアドレス')); ?>

        </div>
        <div class="div">
          <?php echo e(Form::text('email',null,['class' => 'input'])); ?>

        </div>


        <div class="div">
          <?php echo e(Form::label('パスワード')); ?>

        </div>
        <div class="div">
          <?php echo e(Form::password('password',['class' => 'input'])); ?>

        </div>

        <div class="btn-form">
          <?php echo Form::button('<div class="link blue">ログイン</div>', ['class' => "btn", 'type' => 'submit' ]); ?>

        </div>


        <div>新規ユーザーの方は<a href="/register">こちら</a></div>

      <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shu\Documents\Bulletin-board_Kakuta\Bulletin-board-master\resources\views/auth/login.blade.php ENDPATH**/ ?>
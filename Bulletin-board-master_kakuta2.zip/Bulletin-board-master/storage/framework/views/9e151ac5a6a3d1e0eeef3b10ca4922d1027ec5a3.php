<?php $__env->startSection('content'); ?>




<!-- ------------------------------------------- -->

<div class="logout-from">

  <div class="logout-inner">

  <?php if(isset( $errors )): ?>
    <div class="error-message">
      <div class="error-inner">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  <?php endif; ?>
    <?php echo Form::open(); ?>


    <p class="login-title bold">ユーザー登録</p>

    <div class="form">
      <?php echo e(Form::label('ユーザー名')); ?>

      <?php echo e(Form::text('username',null,['class' => 'input'])); ?>

    </div>

    <div class="margin-form form">
      <?php echo e(Form::label('メールアドレス')); ?>

      <?php echo e(Form::text('email',null,['class' => 'input'])); ?>

    </div>

    <div class="margin-form form">
      <?php echo e(Form::label('パスワード')); ?>

      <?php echo e(Form::password('password',['class' => 'input'])); ?>

    </div>

    <div class="margin-form form">
      <?php echo e(Form::label('パスワード確認')); ?>

      <?php echo e(Form::password('password_confirmation',null,['class' => 'input'])); ?>

    </div>

    <div class="btn-form">
      <?php echo Form::button('<div class="link blue">確認</div>', ['class' => "btn", 'type' => 'submit' ]); ?>

    </div>



    <div class="white new-user"><a href="/login">ログイン画面へ戻る</a></div>

    <?php echo Form::close(); ?>

  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shu\Documents\Bulletin-board_Kakuta\Bulletin-board-master\resources\views/auth/register.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="post-form">

        <div class="flex">
            <div class="bold">投稿編集画面</div>
            <div class="link blue"><a href="/logout">ログアウト</a></div>
        </div>

    <?php if(isset( $errors )): ?>
        <div class="error-message">
            <div class="error-inner">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

      <?php echo Form::open(); ?>

            <div class="div">
                <?php echo e(Form::label('サブカテゴリー')); ?>

            </div>


            <div class="div">
                <select name="post_sub_category_id">
                    <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->sub_category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="div">
            <?php echo e(Form::label('タイトル')); ?>

            </div>
            <div class="div">
            <?php echo e(Form::text('title',$post_data->title,['class' => 'input'])); ?>

            </div>
            <div class="div">
            <?php echo e(Form::label('投稿内容')); ?>

            </div>
            <div class="div">
            <?php echo e(Form::textarea('post',$post_data->post,['class' => 'input', 'rows' => '5'])); ?>

            </div>


            <?php echo Form::button('<div class="link red">更新</div>', ['class' => "btn", 'type' => 'submit' ]); ?>

            <div class="link red">
                <a href="<?php echo e(route('post_delete',['post_id'=>$post_data->id])); ?>" onclick="return confirm('この投稿を削除します。よろしいでしょうか？')">
                    削除
                </a>
            </div>
        <?php echo Form::close(); ?>


        <?php if(isset( $errors )): ?>
            <div class="error-message bold">
                <div class="error-inner">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>※<?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shu\Documents\Bulletin-board_Kakuta\Bulletin-board-master\resources\views/post_update.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>



    <div class="post-data">
        <div class="flex">
            <div class="bold">
                掲示板詳細画面
            </div>
            <div class="link blue"><a href="/logout">ログアウト</a></div>
        </div>

        <div class="post-area">


            <div class="flex">
                <div class="flex">
                    <div class="post-name">
                    <?php echo e($post->user->username); ?>さん
                    </div>
                    <div class="div">
                    <?php echo e($post->created_at->format('Y年m月d日')); ?>

                    </div>
                </div>

                <div class="post-view">
                    <?php echo e($view_count); ?>View
                </div>
            </div>

            <div class="flex">
                <div class="post-title">
                    <?php echo e($post->title); ?>

                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                <div class="link red">
                    <a href="<?php echo e(route('post_update_form',['post_id'=>$post->id])); ?>">
                        編集
                    </a>
                </div>
                <?php endif; ?>
            </div>

            <div class="post-left">
                <?php echo e($post->post); ?>

            </div>


            <div class="flex">
                <div class="post-category link blue">
                    <?php echo e($post->subCategories->sub_category); ?>

                </div>

                <div class="flex">
                    <div class="post-comment">
                        コメント数<?php echo e($post->comment_count); ?>

                    </div>
                    <?php if(count($favorites_judge)===1): ?>
                        <span class="likes">
                            <i class="far fa-heart like-toggle liked" data-review-id="<?php echo e($post->id); ?>"></i>
                            <span class="like-counter"><?php echo e($post->post_favorite_count); ?></span>
                        </span>
                    <?php elseif(count($favorites_judge)===0): ?>
                        <span class="likes">
                            <i class="far fa-heart like-toggle" data-review-id="<?php echo e($post->id); ?>"></i>
                            <span class="like-counter"><?php echo e($post->post_favorite_count); ?></span>
                        </span>
                    <?php endif; ?>
                </div>

            </div>

        </div>


        <div class="comment-area">

            <?php $__currentLoopData = $post_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="comment-area-inner">

                    <div class="flex">

                        <div class="flex">
                            <div class="post-name">
                                <?php echo e($comment->user->username); ?>さん
                            </div>
                            <div class="div">
                                <?php echo e($comment->created_at->format('Y年m月d日')); ?>

                            </div>
                        </div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                            <div class="link red">
                                <a href="<?php echo e(route('comment_update_form',['comment_id'=>$comment->id])); ?>">
                                    編集
                                </a>
                            </div>
                        <?php endif; ?>

                    </div>


                    <div class="flex">
                        <div class="div">
                            <?php echo e($comment->comment); ?>

                        </div>


                        <?php if(Auth::user()->comment_isLikedBy($comment->id)): ?>
                            <span class="likes">
                                <i class="far fa-heart like-comment-toggle liked" data-comment-id="<?php echo e($comment->id); ?>"></i>
                                <span class="comment-like-counter"><?php echo e($comment->comment_favorite_count); ?></span>
                            </span><!-- /.likes -->
                        <?php else: ?>
                            <span class="likes">
                                <i class="far fa-heart like-comment-toggle" data-comment-id="<?php echo e($comment->id); ?>"></i>
                                <span class="like-counter"><?php echo e($comment->comment_favorite_count); ?></span>
                            </span><!-- /.likes -->
                        <?php endif; ?>

                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="comment-form">
            <?php echo Form::open(); ?>


                <?php echo e(Form::textarea('comment_create',null,['class' => 'input form-space', 'placeholder' => 'コチラからコメントできます', 'cols'=>'70' , 'rows' => '5'])); ?>


                <?php echo Form::button('<div class="link blue">コメント</div>', ['class' => "btn", 'type' => 'submit' ]); ?>


            <?php echo Form::close(); ?>

        </div>

        <?php if(isset( $errors )): ?>
            <div class="error-message bold">
                <div class="error-inner">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>※<?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shu\Documents\Bulletin-board_Kakuta\Bulletin-board-master\resources\views/post_data.blade.php ENDPATH**/ ?>
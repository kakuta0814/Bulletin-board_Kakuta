<?php $__env->startSection('content'); ?>



<div class="logout-from">

  <div class="added-inner">



    <div class="login-title bold">登録ありがとうございます</div>

    <div class="link blue">
      <a href="/login">
        ログイン画面へ
      </a>
    </div>



  </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shu\Documents\Bulletin-board_Kakuta\Bulletin-board-master\resources\views/auth/added.blade.php ENDPATH**/ ?>
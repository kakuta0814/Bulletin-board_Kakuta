<?php $__env->startSection('content'); ?>
<div class="main">



    <div class="container">
        <div class="inner">
            <div class="bold post-title">掲示板投稿一覧</div>
        <?php if(isset($all_posts)): ?>
            <?php $__currentLoopData = $all_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post">

                    <div class="flex">
                        <div class="post-name">
                            <?php echo e($post->user->username); ?>さん
                        </div>
                        <div class="post-create">
                            <?php echo e($post->created_at->format('Y年m月d日')); ?>

                        </div>
                        <div class="post-view">
                            <?php echo e($post->action_logs_count); ?>View
                        </div>
                    </div>

                    <div class="post-title">
                        <a href="<?php echo e(route('post_data',['post_id'=>$post->id])); ?>">
                            <div><?php echo e($post->title); ?></div>
                        </a>
                    </div>

                    <div class="flex post-center">

                        <div class="post-category link blue">
                            <?php echo e($post->subCategories->sub_category); ?>

                        </div>

                        <div class="post-comment">
                            コメント数<?php echo e($post->comment_count); ?>

                        </div>

                        <div class="div">
                        <?php if(Auth::user()->isLikedBy($post->id)): ?>
                            <span class="likes">
                                <i class="fas fa-heart like-toggle liked" data-review-id="<?php echo e($post->id); ?>"></i>
                            <span class="like-counter"><?php echo e($post->post_favorite_count); ?></span>
                            </span><!-- /.likes -->
                        <?php else: ?>
                            <span class="likes">
                                <i class="fas fa-heart like-toggle white" data-review-id="<?php echo e($post->id); ?>"></i>
                            <span class="like-counter"><?php echo e($post->post_favorite_count); ?></span>
                            </span><!-- /.likes -->
                        <?php endif; ?>
                        </div>

                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </div>
    </div>

    <div class="main-menu">
        <div class="side-menu">
            <div class="side-inner">



            <div class="link blue"><a href="/logout">ログアウト</a></div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                <div class="link red"><a href="/category">カテゴリーを追加</a></div>
            <?php endif; ?>
            <div class="link blue"><a href="/post">投稿</a></div>
            <?php echo Form::open(['url' => '/search', 'method' => 'get']); ?>


            <div class="div">
            <?php echo e(Form::text('search',null,['class' => 'input search-space'])); ?></div>

            <?php echo Form::button('<div class="link blue">検索</div>', ['class' => "btn", 'type' => 'submit' ]); ?>


            <?php echo Form::close(); ?>


            <div class="link blue"><a href="like">いいねした投稿</a></div>
            <div class="link blue"><a href="my_post">自分の投稿</a></div>
        </div>


        <div id="accordion" class="accordion-container">
            <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="accordion-title js-accordion-title"><?php echo e($category->main_category); ?></div>
                        <?php if($category->postSubCategories->isEmpty()): ?>

                        <?php endif; ?>
                        <div class="accordion-content">
                            <?php $__currentLoopData = $category->postSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('search_sub',['sub_id'=>$sub->id])); ?>"><div class="nav-item"><?php echo e($sub->sub_category); ?></div></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!--/.accordion-content-->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><!--/#accordion-->

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\shu\Documents\Bulletin-board_Kakuta\Bulletin-board-master\resources\views/index.blade.php ENDPATH**/ ?>